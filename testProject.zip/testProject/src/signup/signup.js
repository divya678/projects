import React, { useState, useEffect } from "react";
import {
  CitySelect,
  CountrySelect,
  StateSelect,
} from "react-country-state-city";
import PhoneInput from "react-phone-number-input";
import { validateValues } from "../formValidation";
import { useNavigate } from "react-router-dom";

const SignUp = () => {
  const [countries, setCountries] = useState([]);
  const [phone, setPhone] = useState("");
  const [selectedCountry, setSelectedCountry] = useState({});
  const [inputValue, setInputValue] = useState({});
  const [errors, setErrors] = useState({});
  const [submitting, setSubmitting] = useState(false);
  const navigate = useNavigate();
  const [items, setItems] = useState();

  const handleOnchange = (e) => {
    const { value, name } = e.target;
    setInputValue({ ...inputValue, [name]: value });
  };

  const handleSubmit = () => {
    setErrors(validateValues(inputValue, countries, selectedCountry, phone));
    setSubmitting(true);
  };

  useEffect(() => {
    if (Object.keys(errors).length === 0 && submitting) {
      navigate("/login");
      window.location.reload();
      localStorage.setItem("formData", JSON.stringify(inputValue));
    }
  }, [errors]);

  return (
    <div className="container">
      <div className="signupForm">
        <form onSubmit={(e) => e.preventDefault()}>
          <div className="row">
            <p>
              Individual/Enterprise/Government
              <span className="required"> *</span>
            </p>
          </div>
          <div className="row">
            <p className="row">
              <input
                id={`indivudual`}
                name="indivudual"
                type="radio"
                value={"indivudual"}
                onChange={handleOnchange}
                checked
              />
              <label htmlFor={`indivudual`}>{"Indivudual"} </label>
            </p>

            <p className="row">
              <input
                id={`Enterprise`}
                name="Enterprise"
                value={"Enterprise"}
                onChange={handleOnchange}
                type="radio"
              />
              <label htmlFor={`Enterprise`}>{"Enterprise"}</label>
            </p>

            <p className="row">
              <input
                id={`government`}
                name="government"
                onChange={handleOnchange}
                value={"government"}
                type="radio"
              />
              <label htmlFor={`government`}>{"Government"}</label>
            </p>
          </div>
          <div className="row">
            <p className="col">
              <label htmlFor={`firstName`}>
                {"First Name"} <span className="required"> *</span>
              </label>
              <input
                id={`firstName`}
                name="firstName"
                type="text"
                required={true}
                value={inputValue.firstName}
                autoCapitalize="words"
                maxLength="35"
                placeHolder="First Name"
                onChange={handleOnchange}
              />
              {errors.firstName && <p className="errors">{errors.firstName}</p>}
            </p>

            <p className="col">
              <label htmlFor={`lastName`}>{"Last Name"}</label>
              <input
                id={`lastName`}
                name="lastName"
                value={inputValue.lastName}
                type="text"
                required={true}
                autoCapitalize="words"
                maxLength="35"
                placeholder="Last Name"
                onChange={handleOnchange}
              />
            </p>
          </div>
          <div className="row">
            <p className="col">
              <label htmlFor={`email`}>
                {"Email"} <span className="required"> *</span>
              </label>
              <input
                id={`email`}
                name="email"
                value={inputValue.email}
                type="email"
                required={true}
                autoCapitalize="words"
                placeholder="Email"
                onChange={handleOnchange}
              />
              {errors.email && <p className="errors">{errors.email}</p>}
            </p>
          </div>
          <div className="row">
            <p className="col">
              <label htmlFor={`address`}>
                {"Address"} <span className="required"> *</span>
              </label>
              <input
                id={`address`}
                name="address"
                value={inputValue.address}
                type="text"
                required={true}
                autoCapitalize="words"
                placeholder="Address"
                onChange={handleOnchange}
              />
              {errors.address && <p className="errors">{errors.address}</p>}
            </p>
          </div>
          <div className="row">
            <p className="col">
              <label htmlFor={`country`}>
                {"Country"} <span className="required"> *</span>
              </label>
              <CountrySelect
                onChange={(e) => {
                  setCountries(e.id);
                }}
                placeHolder="Select Country"
                name="country"
              />

              {errors.country && <p className="errors">{errors.country}</p>}
            </p>

            <p className="col">
              <label htmlFor={`state`}>
                {"Sate"} <span className="required"> *</span>
              </label>
              <StateSelect
                countryid={countries}
                onChange={(e) => {
                  setSelectedCountry(e.id);
                }}
                name="state"
                placeHolder="Select State"
              />

              {errors.state && <p className="errors">{errors.state}</p>}
            </p>
          </div>
          <div className="row">
            <p className="col">
              <label htmlFor={`city`}>
                {"City"} <span className="required"> *</span>
              </label>
              <CitySelect
                countryid={countries}
                stateid={selectedCountry}
                onChange={(e) => {
                  console.log(e);
                }}
                placeHolder="Select City"
              />

              {errors.city && <p className="errors">{errors.city}</p>}
            </p>

            <p className="col">
              <label htmlFor={`pincode`}>
                {"Pincode"} <span className="required"> *</span>
              </label>
              <input
                id={`pincode`}
                name="pincode"
                value={inputValue.pincode}
                required={true}
                maxLength="6"
                onChange={handleOnchange}
                placeholder="ex:110042"
              />

              {errors.pincode && <p className="errors">{errors.pincode}</p>}
            </p>
          </div>
          <div className="row">
            <p className="col">
              <label htmlFor={`mobileno`}>
                {"Mobile Number"} <span className="required"> *</span>
              </label>

              <PhoneInput
                country={countries}
                enableSearch={true}
                value={phone}
                onChange={(phone) => setPhone(phone)}
              />

              {errors.mobileno && <p className="errors">{errors.mobileno}</p>}
            </p>
          </div>
          <div className="row">
            <p className="col">
              <label htmlFor={`fax`}>{"Fax"}</label>
              <input
                id={`fax`}
                name="fax"
                value={inputValue.fax}
                type="text"
                required={true}
                placeholder="011-55541234"
                onChange={handleOnchange}
              />
            </p>

            <p className="col">
              <label htmlFor={`phone`}>{"Phone"}</label>
              <input
                id={`phone`}
                name="phone"
                value={inputValue.phone}
                type="text"
                required={true}
                placeholder="011-55541234"
                onChange={handleOnchange}
              />
            </p>
          </div>
          <div className="row">
            <p className="col">
              <label htmlFor={`password`}>{"Password"}</label>
              <input
                id={`password`}
                name="password"
                value={inputValue.password}
                type="password"
                required={true}
                onChange={handleOnchange}
              />
              {errors.password && <p className="errors">{errors.password}</p>}
            </p>
          </div>
          <div className="row">
            <p className="col">
              <label htmlFor={`confirmpswd`}>{"Confirm Passoword"}</label>
              <input
                id={`confirmpswd`}
                name="confirmpswd"
                value={inputValue.confirmpswd}
                type="pasword"
                required={true}
                onChange={handleOnchange}
              />
              {errors.confirmpswd && (
                <p className="errors">{errors.confirmpswd}</p>
              )}
            </p>
          </div>
          <div className="row">
            <button className="buttonSignup" onClick={() => handleSubmit()}>
              SIGN UP
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default SignUp;
