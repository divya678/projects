export const validateValues = (
  inputValue,
  countries,
  selectedCountry,
  phone
) => {
  let errors = {};
  const regex =
    /(?=^.{8,}$)((?=.*\d)|(?=.*\W+))(?![.\n])(?=.*[A-Z])(?=.*[a-z]).*$/;
  if (!inputValue.firstName || inputValue.firstName === "") {
    errors.firstName = " Please enter valid first name.";
  }

  if (!inputValue.email || inputValue.email === "") {
    errors.email = "Please enter valid email.";
  }

  if (!inputValue.address || inputValue.address === "") {
    errors.address = "Please enter valid address.";
  }

  if (!phone || phone === "") {
    errors.mobileno = "Please select the country code.";
  }

  if (!inputValue.pincode) {
    errors.pincode = "Please enter valid pincode.";
  }

  if (countries.length === 0) {
    errors.country = "Please Please select your Country.";
  }

  if (JSON.stringify(selectedCountry) === "{}") {
    errors.state = "Please select your State.";
  }

  if (JSON.stringify(selectedCountry) === "{}") {
    errors.city = "Please select your City.";
  }

  if (!inputValue.password || !regex.test(inputValue.password)) {
    errors.password =
      "Must contain at least one number and one upppercase and lowercase, and at least 8 or more characters";
  }

  if (
    !inputValue.confirmpswd ||
    (inputValue.password &&
      inputValue.confirmpswd &&
      inputValue.confirmpswd !== inputValue.password)
  ) {
    errors.confirmpswd = "confirm password should be same as password.";
  }

  return errors;
};
