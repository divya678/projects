import React, { useEffect, useState } from "react";
import Login from "./login.js/login";
import SignUp from "./signup/signup";
import { useNavigate } from "react-router-dom";

const Logincontainer = () => {
  const [switchTab, setSwitchTab] = useState(true);
  const navigate = useNavigate();
  const [formData, setFormData] = useState([]);

  const path = window.location.pathname;
  useEffect(() => {
    if (path === "/login") {
      setSwitchTab(false);
    }
  }, [switchTab]);

  return (
    <>
      <div className="main-container">
        <div className="row">
          <button
            className={switchTab ? "button" : "buttonActive"}
            onClick={() => {
              navigate("/login");
              setSwitchTab(false);
            }}
          >
            Login
          </button>
          <button
            className={switchTab ? "buttonActive" : "button"}
            onClick={() => {
              navigate("/signup");
              setSwitchTab(true);
            }}
          >
            Sign Up
          </button>

          {path === "login" ? (
            <Login
              formData={formData}
              setSwitchTab={setSwitchTab()}
              switchTab={switchTab}
            />
          ) : (
            path === "signup" && (
              <SignUp setFormData={setFormData()} formData={formData} />
            )
          )}
        </div>
      </div>
    </>
  );
};

export default Logincontainer;
