import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

const Login = () => {
  const navigate = useNavigate();
  const [input, setInput] = useState({});
  const [items, setItems] = useState();
  const [error, setErrors] = useState(false);

  const handleOnchange = (e) => {
    const { name, value } = e.target;
    setInput({ ...input, [name]: value });
  };

  useEffect(() => {
    const items = JSON.parse(localStorage.getItem("formData"));
    if (items) {
      setItems(items);
    }
  }, []);

  const login = () => {
    if (
      items &&
      items.email === input.email &&
      items.password === input.password
    ) {
      navigate("/product");
      window.location.reload();
      setErrors(false);
    } else {
      setErrors(true);
    }
  };
  return (
    <div className="loginForm">
      <div className="row">
        <p className="col">
          <label htmlFor={`email`}>{"Email"}</label>
          <input
            id={`email`}
            value={input.email}
            name="email"
            type="email"
            onChange={handleOnchange}
          />
        </p>
      </div>

      <div className="row">
        <p className="col">
          <label htmlFor={`password`}>{"Password"}</label>
          <input
            id={`password`}
            name="password"
            value={input.password}
            onChange={handleOnchange}
          />
        </p>
      </div>

      <div className="row">
        {error && <p>Invalid password or Email ID</p>}
        <a className="link" href=".home">
          Forgot Password{" "}
        </a>
      </div>

      <div className="row">
        <button className="loginButton" onClick={login}>
          Log me in{" "}
        </button>
      </div>
    </div>
  );
};

export default Login;
