import React from "react";
import ProductView from "./product/product";
import Logincontainer from "./logincontainer";
import { Route, Routes } from "react-router-dom";
import Login from "./login.js/login";
import SignUp from "./signup/signup";

const App = () => {
  const path = window.location.pathname;
  return (
    <>
      <div className="tab">
        {path !== "/product" && <Logincontainer />}
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/signup" element={<SignUp />} />
          <Route path="/product" element={<ProductView />}></Route>
        </Routes>
      </div>
    </>
  );
};

export default App;
