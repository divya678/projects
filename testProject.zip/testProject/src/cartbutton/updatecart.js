import React, { useState, useEffect } from "react";

const Updatecart = ({ setCart, cart, itemId }) => {
  const [count, setCount] = useState(1);
  const [message, setMessage] = useState(false);

  const decQuantity = () => {
    if (count > 1) {
      setCount(count - 1);
    }
  };

  const incQuantity = (cardId) => {
    if (count < 20) {
      setCount(count + 1);
    }
  };
  const addToCart = (cartId) => {
    if (count > 0) {
      setCart([...cart, count]);
      setMessage(true);
    }
  };

  const cartItem =
  cart.length > 0
    ? cart.reduce(
        (previousValue, currentValue) => previousValue + currentValue
      )
    : "";

    useEffect(() => {
      setTimeout(() => {
        setMessage("")
      }, 60000);
    }, [message])

  return (
    <>
      <div className="row">
        <button onClick={decQuantity}>-</button>
        <h2>{count}</h2>
        <button onClick={incQuantity}>+</button>
        <button className="cart" onClick={() => addToCart(itemId)}>
          Add To Cart
        </button>
      </div>
      <p> {message && <div>{cartItem} Items added to the cart</div>}</p>
    </>
  );
};

export default Updatecart;
