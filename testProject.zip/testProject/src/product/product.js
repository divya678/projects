import React, { useEffect, useState } from "react";
import Updatecart from "../cartbutton/updatecart.js";

const ProductView = () => {
  const [productList, setProductList] = useState();
  const [cart, setCart] = useState([]);
  const fetchData = async () => {
    try {
      const response = await fetch("https://fakestoreapi.com/products");
      const data = await response.json();
      setProductList(data);
    } catch (err) {
      console.log(err, "Not able to fetch Data");
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const cartItem =
    cart.length > 0
      ? cart.reduce(
          (previousValue, currentValue) => previousValue + currentValue
        )
      : "";

  return (
    <div className="productContainer">
      <div className="card">
        <div className="cartIcon">Cart Item {cartItem}</div>
        <h3>{"clothing for men and women"}</h3>
        <div className="row-card">
          {productList &&
            productList.map((item) => {
              return (
                <>
                  {(item.category === "men's clothing" ||
                    "women's clothing") && (
                    <div className="item-card">
                      <div className="imageWrapper">
                        <img src={item.image} alt="img" />
                      </div>
                      <div className="content">
                        <h3>{item.title}</h3>

                        <h4>{item.title}</h4>
                        <div className="col">
                          <Updatecart
                            itemId={item.id}
                            setCart={setCart}
                            cart={cart}
                          />
                          <h6> {` Rs ${item.price}`}</h6>
                        </div>
                      </div>
                    </div>
                  )}
                </>
              );
            })}
        </div>
      </div>

      <div className="card">
        <h3>{"electronics"}</h3>
        <div className="row-card">
          {productList &&
            productList.map((item) => {
              return (
                <>
                  {item.category === "electronics" && (
                    <div className="item-card" key={item.id}>
                      <div className="imageWrapper">
                        <img src={item.image} alt="img" />
                      </div>
                      <div className="content">
                        <h3>{item.title}</h3>

                        <h4>{item.title}</h4>
                        <div className="col">
                          <Updatecart
                            key={item.id}
                            setCart={setCart}
                            cart={cart}
                          />
                          <h6> {` Rs ${item.price}`}</h6>
                        </div>
                      </div>
                    </div>
                  )}
                </>
              );
            })}
        </div>
      </div>
    </div>
  );
};

export default ProductView;
